// Este é o pacote onde nossa classe está localizada
package sptech.school;

// Declaração da classe principal do programa
public class Main {

    // Método main: ponto de entrada da aplicação
    public static void main(String[] args) {

        System.out.println("\nVariáveis Primitivas\n");

        // Declaração de variáveis do tipo inteiro (primitivos)
        byte numeroByte = 1;       // Ocupa 8 bits (-128 a 127)
        short numeroCurto = 1;      // Ocupa 16 bits (-32.768 a 32.767)
        int numeroInteiro = 1;      // Ocupa 32 bits (-2^31 a 2^31 - 1)
        long numeroLongo = 1L;      // Ocupa 64 bits (-2^63 a 2^63 - 1), o "L" indica que é um long

        // Impressão dos valores inteiros primitivos
        System.out.println("Valor em byte (primitivo): " + numeroByte);
        System.out.println("Valor em short (primitivo): " + numeroCurto);
        System.out.println("Valor em int (primitivo): " + numeroInteiro);
        System.out.println("Valor em long (primitivo): " + numeroLongo);

        // Declaração de variáveis de ponto flutuante (primitivos)
        float numeroDecimalFloat = 1.1f;  // Ocupa 32 bits, precisa do sufixo "f"
        double numeroDecimalDouble = 1.1; // Ocupa 64 bits, maior precisão que float

        // Impressão dos valores de ponto flutuante primitivos
        System.out.println("Valor em float (primitivo): " + numeroDecimalFloat);
        System.out.println("Valor em double (primitivo): " + numeroDecimalDouble);

        // Outros tipos primitivos
        char caractereSimbolo = 'A';     // Ocupa 16 bits, representa um único caractere (Unicode)
        boolean valorBooleano = false;   // Ocupa 1 bit (true ou false)

        // Impressão dos valores de tipos primitivos char e boolean
        System.out.println("Valor em char (primitivo): " + caractereSimbolo);
        System.out.println("Valor em boolean (primitivo): " + valorBooleano);

        System.out.println("\nVariáveis Wrappers\n");

        // Declaração de tipos Wrapper (versões objeto dos primitivos)
        Byte numeroByteWrapper = 1;          // Wrapper para byte (8 bits)
        Short numeroCurtoWrapper = 1;        // Wrapper para short (16 bits)
        Integer numeroInteiroWrapper = 1;    // Wrapper para int (32 bits)
        Long numeroLongoWrapper = 1L;        // Wrapper para long (64 bits)

        // Impressão dos valores inteiros Wrappers
        System.out.println("Valor em Byte (Wrapper): " + numeroByteWrapper);
        System.out.println("Valor em Short (Wrapper): " + numeroCurtoWrapper);
        System.out.println("Valor em Integer (Wrapper): " + numeroInteiroWrapper);
        System.out.println("Valor em Long (Wrapper): " + numeroLongoWrapper);

        // Declaração de tipos Wrapper para números de ponto flutuante
        Float numeroDecimalFloatWrapper = 1.1f;  // Wrapper para float (32 bits)
        Double numeroDecimalDoubleWrapper = 1.1; // Wrapper para double (64 bits)

        // Impressão dos valores de ponto flutuante Wrappers
        System.out.println("Valor em Float (Wrapper): " + numeroDecimalFloatWrapper);
        System.out.println("Valor em Double (Wrapper): " + numeroDecimalDoubleWrapper);

        // Declaração de Wrapper para char e boolean
        Character caractereWrapper = 'W';   // Wrapper para char (16 bits)
        Boolean valorBooleanoWrapper = null; // Wrapper para boolean (1 bit, pode ser nulo)

        // Impressão dos valores Wrapper de char e boolean
        System.out.println("Valor em Character (Wrapper): " + caractereWrapper);
        System.out.println("Valor em Boolean (Wrapper): " + valorBooleanoWrapper);

        // Declaração de uma String
        String mensagemTexto = "Hello, World!!!";
        System.out.println("Valor em String (Wrapper): " + mensagemTexto);

        // Declaração de duas Strings para comparação
        String textoMaiusculo = "TEXTO";
        String textoMinusculo = "texto";

        // Comparação ignorando maiúsculas/minúsculas
        boolean saoIguaisIgnorandoCase = textoMaiusculo.equalsIgnoreCase(textoMinusculo);

        // Impressão do resultado da comparação
        System.out.println("\nValor da comparação entre Strings: " + saoIguaisIgnorandoCase);

        // Uso de um char numérico
        char caractereASCII = 65;  // 65 representa 'A' na tabela ASCII
        int valorNumericoDoCaractere = caractereASCII; // Conversão implícita de char para int
        System.out.println("Valor inteiro da conversão implícita: " + valorNumericoDoCaractere);
    }
}
